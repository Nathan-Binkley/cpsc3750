import { SimpleForm, SimpleShowLayout, TextField, TextInput, Datagrid, ResourceField, List, Edit, Create, Show} from 'react-admin';
import { GradesList } from './Grades';
import { GradesTable } from './GradesTable';




export const StudentsShow = props => (
	<Show {...props}>
		<SimpleShowLayout>
			<TextField source='id'/>
			<TextField source='name'/>
			<GradesTable />
		</SimpleShowLayout>
	</Show>
);

export const StudentsEdit = props => (
	<Edit {...props}>
		<SimpleForm>
			<TextField source='id'/>
			<TextInput source='name'/>
		</SimpleForm>
	</Edit>
);

export const StudentsList = props => (
	<List {...props}>
		<Datagrid rowClick='edit'>
			<TextField source='id'/>
			<TextField source='name'/>
		</Datagrid>
	</List>
);

export const StudentsCreate = props => (
	<Create {...props}>
		<SimpleForm>
			<TextInput source='id'/>
			<TextInput source='name'/>
		</SimpleForm>
	</Create>
);


